---
name: OSVR Issue Template
about: Basic Issue template for issue based branching workflow
title: ''
labels: ''
assignees: ''

---
# Project
UI/GESTURING

# Acceptance Criteria

- [ ] CHECKLIST_ITEM_1
- [ ] CHECKLIST_ITEM_2
- [ ] CHECKLIST_ITEM_3

## Notes

NOTES_FOR_ASSIGNEE
